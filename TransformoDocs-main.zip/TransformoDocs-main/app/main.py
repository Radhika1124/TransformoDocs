from ui import main as ui_main

if __name__ == "__main__":
    ui_main()